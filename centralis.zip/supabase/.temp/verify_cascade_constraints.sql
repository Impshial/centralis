select conrelid::regclass::text as table_name, conname, confdeltype
from pg_constraint
where conname in (
  'canvas_groups_universe_id_fkey',
  'canvas_notes_universe_id_fkey',
  'element_groups_universe_id_fkey',
  'element_layer_assignments_universe_id_fkey',
  'element_links_universe_id_fkey',
  'elements_universe_id_fkey',
  'expanded_views_universe_id_fkey',
  'universe_custom_fields_universe_id_fkey',
  'universe_layers_universe_id_fkey',
  'chronicle_modules_element_id_fkey',
  'element_custom_fields_element_id_fkey',
  'element_template_field_values_element_id_fkey',
  'expanded_views_element_id_fkey',
  'element_links_source_element_id_fkey',
  'element_links_target_element_id_fkey',
  'universe_layer_entries_layer_id_fkey',
  'element_layer_assignments_layer_id_fkey',
  'element_layer_assignments_entry_id_fkey',
  'expanded_view_nodes_expanded_view_id_fkey',
  'expanded_view_edges_expanded_view_id_fkey',
  'expanded_view_edges_source_node_id_fkey',
  'expanded_view_edges_target_node_id_fkey',
  'expanded_view_node_fields_node_id_fkey',
  'elements_group_id_fkey'
)
order by table_name, conname;
