select conrelid::regclass::text as table_name, conname, confdeltype
from pg_constraint
where conrelid = 'public.element_links'::regclass
order by conname;
